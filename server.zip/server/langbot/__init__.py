default_app_config = 'langbot.apps.LangbotConfig'
